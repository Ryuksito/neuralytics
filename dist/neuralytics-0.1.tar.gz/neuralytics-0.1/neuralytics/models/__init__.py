from .simple_linear_regression import *
from .linear_regresion import *