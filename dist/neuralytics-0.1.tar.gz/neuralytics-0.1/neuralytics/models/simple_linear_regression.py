

class SimpleLinearRegression():
    pass