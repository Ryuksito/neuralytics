# neuralytics

## how to install with pip: pip install git+https://github.com/Ryuksito/neuralytics.git